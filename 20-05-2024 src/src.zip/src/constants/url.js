export const adminUrl = "http://122.165.52.124:8080/api/v1/"; 
export const loginUrl = "";

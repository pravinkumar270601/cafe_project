export const CreateEmployeeTableHeaders = [
  "S.no",
  "Employee Name",
  "Employee Id",
  "Check-In Date",
  "Check-In Time",
  "Check-Out Date",
  "Check-Out Time",
  "Status",

];



export const CreateEmployeeTableValues = [
  {
    "Sno": "1",
    "EmployeeId": "001",
    "EmployeeName": "Biddu",
    
    "Check_In_Date": "19 April 2023",
    "Check_In_Time": "07:00",
    "Check_Out_Date": "19 April 2023",
    "Check_Out_Time": "11:00",
    "Status": "Out"

    
  },
  {
    "Sno": "2",
    "EmployeeId": "002",
    "EmployeeName": "Pravin M",
    
    "Check_In_Date": "19 April 2023",
    "Check_In_Time": "07:00",
    "Check_Out_Date": "19 April 2023",
    "Check_Out_Time": "11:00",
    "Status": "Out"

    
  },
  {
    "Sno": "3",
    "EmployeeId": "003",
    "EmployeeName": "Pravin R",
    
    "Check_In_Date": "19 April 2023",
    "Check_In_Time": "07:00",
    "Check_Out_Date": "19 April 2023",
    "Check_Out_Time": "11:00",
    "Status": "Out"

    
  },
  {
    "Sno": "4",
    "EmployeeId": "004",
    "EmployeeName": "Valla",
    
    "Check_In_Date": "19 April 2023",
    "Check_In_Time": "07:00",
    "Check_Out_Date": "19 April 2023",
    "Check_Out_Time": "11:00",
    "Status": "Out"

  },
  {
    "Sno": "5",
    "EmployeeId": "006",
  "EmployeeName": "Arun",
  
  "Check_In_Date": "19 April 2023",
  "Check_In_Time": "07:00",
  "Check_Out_Date": "19 April 2023",
  "Check_Out_Time": "11:00",
  "Status": "Out"

  },
  {
    "Sno": "6",
    "EmployeeId": "006",
    "EmployeeName": "Dinesh",
   
    "Check_In_Date": "19 April 2023",
    "Check_In_Time": "07:00",
    "Check_Out_Date": "19 April 2023",
    "Check_Out_Time": "11:00",
    "Status": "Out"

  },
  {
    "Sno": "7",
    "EmployeeId": "007",
    "EmployeeName": "Binu",
    
    "Check_In_Date": "19 April 2023",
    "Check_In_Time": "07:00",
    "Check_Out_Date": "19 April 2023",
    "Check_Out_Time": "11:00",
    "Status": "Out"

  },
  {
    "Sno": "8",
    "EmployeeId": "008",
    "EmployeeName": "Raj",
  
    "Check_In_Date": "19 April 2023",
    "Check_In_Time": "07:00",
    "Check_Out_Date": "19 April 2023",
    "Check_Out_Time": "11:00",
    "Status": "Out"

  },
  
];